# Python

This document follows what I did to learn the python by using the pycharm IDE starting with the installation of the tools and other utilities on a fresh Ubuntu installation version 22.04.1 LTS. 
 > I'll be using Linux/debian system so please follow along. I'll share the links for installation on MacOS and windows.

## Check if python is installed on the system using
python version
if not installed then first update the system then install the python3 - 
```
sudo apt update
sudo apt install python3
```

## Install pycharm using JetBrains Toolbox app
1. Go to [Toolbox App web page](https://www.jetbrains.com/toolbox/app/) and download the .tar.gz
2. Extract the tarball to a directory that supports file execution.
For example, if the downloaded version is 1.17.7391, you can extract it to the recommended /opt directory using the following command:
```
$ sudo tar -xzf jetbrains-toolbox-1.17.7391.tar.gz -C /opt
$ sudo chmod +x /opt/jetbrains-toolbox-1.27.2.13801/jetbrains-toolbox
$ ./jetbrains-toolbox
```
3. Execute the jetbrains-toolbox binary from the extracted directory to run the Toolbox App.

After you run the Toolbox App for the first time, it will automatically add the Toolbox App icon Toolbox App icon to the main menu.
 > If this doesn't work then your system is missing the required FUSE packages, you can install then using on Ubuntu (>= 22.04):
 ```
 $ sudo add-apt-repository universe
 $ sudo apt install libfuse2
 ```
 For other versions please check [FUSE](https://github.com/AppImage/AppImageKit/wiki/FUSE)
 Now you can run the JetBrains Toolbox using
 ```
 $ ./jetbrains-toolbox
 ```

4. Select the product that you want to install.
To install a specific version, click App actions more and select Available versions.
 > ![toolbox](https://resources.jetbrains.com/help/img/idea/2022.3/py_toolbox_app.png)
